package Controladora;

import Dominio.Habitacion;
import Dominio.Tarifa;
import Persistencia.PTarifa;
import Persistencia.PHabitacion;

import java.time.LocalDate;
import java.util.Scanner;

public class ControladoraTarifa {
    private static Scanner escaner = new Scanner(System.in);

    public void agregarTarifa() {
        System.out.println("Agregar nueva tarifa");

        System.out.print("Ingrese ID de la habitación: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        Habitacion habitacion = PHabitacion.conseguirHabitacion(idHabitacion);
        if (habitacion == null) {
            System.out.println("Habitación no encontrada.");
            return;
        }

        System.out.print("Ingrese la fecha de inicio (YYYY-MM-DD): ");
        LocalDate fechaInicio = LocalDate.parse(escaner.nextLine());

        System.out.print("Ingrese el precio por noche: ");
        double precioPorNoche = Double.parseDouble(escaner.nextLine());

        Tarifa tarifa = new Tarifa(habitacion, fechaInicio, precioPorNoche);

        if (PTarifa.agregarTarifa(tarifa)) {
            System.out.println("Tarifa agregada con éxito.");
        } else {
            System.out.println("Hubo un error al agregar la tarifa.");
        }
    }

    public void eliminarTarifa() {
        System.out.print("Ingrese ID de la tarifa a eliminar: ");
        int idTarifa = Integer.parseInt(escaner.nextLine());

        if (PTarifa.eliminarTarifa(idTarifa)) {
            System.out.println("Tarifa eliminada con éxito.");
        } else {
            System.out.println("Error al eliminar la tarifa.");
        }
    }

    public void modificarTarifa() {
        System.out.print("Ingrese ID de la tarifa a modificar: ");
        int idTarifa = Integer.parseInt(escaner.nextLine());

        Tarifa tarifa = PTarifa.conseguirTarifa(idTarifa);
        if (tarifa == null) {
            System.out.println("Tarifa no encontrada.");
            return;
        }

        System.out.print("Ingrese nuevo ID de hotel (actual: " + tarifa.getHabitacion().getHotel().getIdHotel() + "): ");
        String nuevoIdHotelStr = escaner.nextLine();
        if (!nuevoIdHotelStr.isEmpty()) {
            int nuevoIdHotel = Integer.parseInt(nuevoIdHotelStr);
            Habitacion nuevaHabitacion = PHabitacion.conseguirHabitacion(nuevoIdHotel); // Método para obtener la habitación del nuevo hotel
            if (nuevaHabitacion != null) {
                tarifa.setHabitacion(nuevaHabitacion);
            } else {
                System.out.println("No se encontró habitación en el nuevo hotel.");
            }
        }

        System.out.print("Ingrese nuevo precio por noche (" + tarifa.getPrecioPorNoche() + "): ");
        String nuevoPrecioStr = escaner.nextLine();
        if (!nuevoPrecioStr.isEmpty()) {
            tarifa.setPrecioPorNoche(Double.parseDouble(nuevoPrecioStr));
        }

        System.out.print("Ingrese nueva fecha de inicio (" + tarifa.getFechaInicio() + "): ");
        String nuevaFechaInicioStr = escaner.nextLine();
        if (!nuevaFechaInicioStr.isEmpty()) {
            tarifa.setFechaInicio(LocalDate.parse(nuevaFechaInicioStr));
        }

        if (PTarifa.modificarTarifa(tarifa)) {
            System.out.println("Tarifa modificada con éxito.");
        } else {
            System.out.println("Error al modificar la tarifa.");
        }
    }

    public void conseguirTarifa() {
        System.out.print("Ingrese ID de la tarifa a buscar: ");
        int idTarifa = Integer.parseInt(escaner.nextLine());

        Tarifa tarifa = PTarifa.conseguirTarifa(idTarifa);
        if (tarifa != null) {
            System.out.println("ID: " + tarifa.getIdTarifa() + ", ID Hotel: " + tarifa.getHabitacion().getHotel().getIdHotel() +
                    ", Fecha de Inicio: " + tarifa.getFechaInicio() + ", Precio por Noche: " + tarifa.getPrecioPorNoche());
        } else {
            System.out.println("Tarifa no encontrada.");
        }
    }

    public void listarTarifas() {
        System.out.println("Listado de tarifas:");
        for (Tarifa tarifa : PTarifa.listarTarifas()) {
            System.out.println("ID: " + tarifa.getIdTarifa() + ", ID Hotel: " + tarifa.getHabitacion().getHotel().getIdHotel() +
                    ", Fecha de Inicio: " + tarifa.getFechaInicio() + ", Precio por Noche: " + tarifa.getPrecioPorNoche());
        }
    }
}
