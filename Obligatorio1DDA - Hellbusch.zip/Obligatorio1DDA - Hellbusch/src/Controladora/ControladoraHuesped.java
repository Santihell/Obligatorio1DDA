package Controladora;

import Dominio.Huesped;
import Persistencia.PHuesped;

import java.util.Scanner;

public class ControladoraHuesped {
    private static Scanner escaner = new Scanner(System.in);

    public void agregarHuesped() {
        System.out.println("Agregar huésped");

        int idHuesped;
        do {
            System.out.print("Ingrese ID del huésped: ");
            try {
                idHuesped = Integer.parseInt(escaner.nextLine());
            } catch (Exception e) {
                idHuesped = 0;
                System.out.println("ID inválido. Intente nuevamente.");
            }
        } while (idHuesped == 0);

        System.out.print("Ingrese nombre: ");
        String nombre = escaner.nextLine();

        System.out.print("Ingrese apellido paterno: ");
        String aPaterno = escaner.nextLine();

        System.out.print("Ingrese apellido materno: ");
        String aMaterno = escaner.nextLine();

        System.out.print("Ingrese tipo de documento: ");
        String tipoDocumento = escaner.nextLine();

        System.out.print("Ingrese número de documento: ");
        String numDocumento = escaner.nextLine();

        System.out.print("Ingrese fecha de nacimiento (YYYY-MM-DD): ");
        String fechaNacimiento = escaner.nextLine();

        System.out.print("Ingrese teléfono: ");
        String telefono = escaner.nextLine();

        System.out.print("Ingrese país: ");
        String pais = escaner.nextLine();

        Huesped huesped = new Huesped(idHuesped, nombre, aPaterno, aMaterno, tipoDocumento,
                numDocumento, fechaNacimiento, telefono, pais);

        if (PHuesped.agregarHuesped(huesped)) {
            System.out.println("Huésped agregado con éxito.");
        } else {
            System.out.println("Hubo un error al agregar el huésped.");
        }
    }

    public void eliminarHuesped() {
        System.out.print("Ingrese ID del huésped a eliminar: ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        if (PHuesped.eliminarHuesped(idHuesped)) {
            System.out.println("Huésped eliminado con éxito.");
        } else {
            System.out.println("No se pudo eliminar el huésped.");
        }
    }

    public void modificarHuesped() {
        System.out.print("Ingrese ID del huésped a modificar: ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        Huesped huesped = PHuesped.conseguirHuesped(idHuesped);
        if (huesped == null) {
            System.out.println("Huésped no encontrado.");
            return;
        }

        System.out.print("Ingrese nuevo nombre (" + huesped.getNombre() + "): ");
        String nombre = escaner.nextLine();
        if (!nombre.isEmpty()) huesped.setNombre(nombre);

        System.out.print("Ingrese nuevo apellido paterno (" + huesped.getaPaterno() + "): ");
        String aPaterno = escaner.nextLine();
        if (!aPaterno.isEmpty()) huesped.setaPaterno(aPaterno);

        System.out.print("Ingrese nuevo apellido materno (" + huesped.getaMaterno() + "): ");
        String aMaterno = escaner.nextLine();
        if (!aMaterno.isEmpty()) huesped.setaMaterno(aMaterno);

        System.out.print("Ingrese nuevo tipo de documento (" + huesped.getTipoDocumento() + "): ");
        String tipoDocumento = escaner.nextLine();
        if (!tipoDocumento.isEmpty()) huesped.setTipoDocumento(tipoDocumento);

        System.out.print("Ingrese nuevo número de documento (" + huesped.getNumDocumento() + "): ");
        String numDocumento = escaner.nextLine();
        if (!numDocumento.isEmpty()) huesped.setNumDocumento(numDocumento);

        System.out.print("Ingrese nueva fecha de nacimiento (" + huesped.getFechaNacimiento() + "): ");
        String fechaNacimiento = escaner.nextLine();
        if (!fechaNacimiento.isEmpty()) huesped.setFechaNacimiento(fechaNacimiento);

        System.out.print("Ingrese nuevo teléfono (" + huesped.getTelefono() + "): ");
        String telefono = escaner.nextLine();
        if (!telefono.isEmpty()) huesped.setTelefono(telefono);

        System.out.print("Ingrese nuevo país (" + huesped.getPais() + "): ");
        String pais = escaner.nextLine();
        if (!pais.isEmpty()) huesped.setPais(pais);

        if (PHuesped.modificarHuesped(huesped)) {
            System.out.println("Huésped modificado con éxito.");
        } else {
            System.out.println("Hubo un error al modificar el huésped.");
        }
    }

    public void conseguirHuesped() {
        System.out.print("Ingrese ID del huésped: ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        Huesped huesped = PHuesped.conseguirHuesped(idHuesped);
        if (huesped != null) {
            System.out.println(huesped);
        } else {
            System.out.println("Huésped no encontrado.");
        }
    }

    public void listarHuespedes() {
        System.out.println("Listado de huéspedes:");
        for (Huesped huesped : PHuesped.listarHuespedes()) {
            System.out.println(huesped);
        }
    }
}
