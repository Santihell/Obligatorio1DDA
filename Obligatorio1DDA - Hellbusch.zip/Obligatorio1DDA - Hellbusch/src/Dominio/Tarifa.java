package Dominio;

import java.time.LocalDate;

public class Tarifa {
    private int idTarifa; // Añadir el atributo idTarifa
    private Habitacion habitacion;
    private LocalDate fechaInicio;
    private double precioPorNoche;

    // Constructor con idTarifa
    public Tarifa(int idTarifa, Habitacion habitacion, LocalDate fechaInicio, double precioPorNoche) {
        this.idTarifa = idTarifa;
        this.habitacion = habitacion;
        this.fechaInicio = fechaInicio;
        this.precioPorNoche = precioPorNoche;
    }

    // Constructor sin idTarifa, para crear nuevas tarifas
    public Tarifa(Habitacion habitacion, LocalDate fechaInicio, double precioPorNoche) {
        this.habitacion = habitacion;
        this.fechaInicio = fechaInicio;
        this.precioPorNoche = precioPorNoche;
    }

    public void setHabitacion(Habitacion habitacion) {
        this.habitacion = habitacion;
    }

    public int getIdTarifa() { // Getter para idTarifa
        return idTarifa;
    }

    public Habitacion getHabitacion() { // Getter para habitacion
        return habitacion;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public double getPrecioPorNoche() {
        return precioPorNoche;
    }

    public void setPrecioPorNoche(double precioPorNoche) {
        this.precioPorNoche = precioPorNoche;
    }

    public Tarifa() {
        super();
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }
}
