package Persistencia;

import Dominio.Habitacion;
import Dominio.Hotel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PHabitacion {
    private static Conexion conexion = new Conexion();

    // Agregar una habitación
    public static boolean agregarHabitacion(Habitacion habitacion) {
        String sql = "INSERT INTO Habitacion(idHabitacion, capacidadCamas, camaMatrimonial, aireAcondicionado, balcon, vista, amenities, ocupada, idHotel) " +
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                habitacion.getIdHabitacion(), habitacion.getCapacidadCamas(), habitacion.isCamaMatrimonial(),
                habitacion.isAireAcondicionado(), habitacion.isBalcon(), habitacion.isVista(),
                habitacion.isAmenities(), habitacion.isOcupada(), habitacion.getHotel().getIdHotel()
        ));
        return conexion.consulta(sql, parametros);
    }

    // Eliminar una habitación por su ID
    public static boolean eliminarHabitacion(int idHabitacion) {
        String sql = "DELETE FROM Habitacion WHERE idHabitacion=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(idHabitacion));
        return conexion.consulta(sql, parametros);
    }

    // Modificar los datos de una habitación
    public static boolean modificarHabitacion(Habitacion habitacion) {
        String sql = "UPDATE Habitacion SET capacidadCamas=?, camaMatrimonial=?, aireAcondicionado=?, balcon=?, vista=?, amenities=?, ocupada=?, idHotel=? " +
                "WHERE idHabitacion=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                habitacion.getCapacidadCamas(), habitacion.isCamaMatrimonial(), habitacion.isAireAcondicionado(),
                habitacion.isBalcon(), habitacion.isVista(), habitacion.isAmenities(),
                habitacion.isOcupada(), habitacion.getHotel().getIdHotel(),
                habitacion.getIdHabitacion()
        ));
        return conexion.consulta(sql, parametros);
    }

    // Conseguir una habitación específica por su ID
    public static Habitacion conseguirHabitacion(int idHabitacion) {
        String sql = "SELECT * FROM Habitacion WHERE idHabitacion=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(idHabitacion));

        List<List<Object>> resultado = conexion.seleccion(sql, parametros);
        if (resultado.isEmpty()) return null;

        List<Object> registro = resultado.get(0);
        Hotel hotel = new Hotel((int) registro.get(8), "", "", "", 0, "", "", null);
        return new Habitacion(
                (int) registro.get(0), (int) registro.get(1), (boolean) registro.get(2),
                (boolean) registro.get(3), (boolean) registro.get(4), (boolean) registro.get(5),
                (boolean) registro.get(6), (boolean) registro.get(7),
                hotel
        );
    }

    // Listar todas las habitaciones
    public static ArrayList<Habitacion> listarHabitaciones() {
        String sql = "SELECT * FROM Habitacion";
        List<List<Object>> registros = conexion.seleccion(sql, null);
        ArrayList<Habitacion> habitaciones = new ArrayList<>();

        for (List<Object> registro : registros) {
            Hotel hotel = new Hotel((int) registro.get(8), "", "", "", 0, "", "", null);
            Habitacion habitacion = new Habitacion(
                    (int) registro.get(0), (int) registro.get(1), (boolean) registro.get(2),
                    (boolean) registro.get(3), (boolean) registro.get(4), (boolean) registro.get(5),
                    (boolean) registro.get(6), (boolean) registro.get(7),
                    hotel
            );
            habitaciones.add(habitacion);
        }
        return habitaciones;
    }

    // Listar habitaciones con reservas
    public static List<Habitacion> listarHabitacionesConReserva() {
        List<Habitacion> habitaciones = new ArrayList<>();
        String sql = "SELECT h.* FROM Habitacion h JOIN Reserva r ON h.idHabitacion = r.idHabitacion";

        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Habitacion habitacion = new Habitacion(
                        rs.getInt("idHabitacion"),
                        rs.getInt("capacidadCamas"),
                        rs.getBoolean("camaMatrimonial"),
                        rs.getBoolean("aireAcondicionado"),
                        rs.getBoolean("balcon"),
                        rs.getBoolean("vista"),
                        rs.getBoolean("amenities"),
                        rs.getBoolean("ocupada"),
                        new Hotel(rs.getInt("idHotel"), "", "", "", 0, "", "", null)
                );
                habitaciones.add(habitacion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return habitaciones;
    }

    // Listar habitaciones sin reservas
    public static List<Habitacion> listarHabitacionesSinReserva() {
        List<Habitacion> habitaciones = new ArrayList<>();
        String sql = "SELECT h.* FROM Habitacion h LEFT JOIN Reserva r ON h.idHabitacion = r.idHabitacion WHERE r.idReserva IS NULL";

        try (Connection conn = Conexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Habitacion habitacion = new Habitacion(
                        rs.getInt("idHabitacion"),
                        rs.getInt("capacidadCamas"),
                        rs.getBoolean("camaMatrimonial"),
                        rs.getBoolean("aireAcondicionado"),
                        rs.getBoolean("balcon"),
                        rs.getBoolean("vista"),
                        rs.getBoolean("amenities"),
                        rs.getBoolean("ocupada"),
                        new Hotel(rs.getInt("idHotel"), "", "", "", 0, "", "", null)
                );
                habitaciones.add(habitacion);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return habitaciones;
    }
}
