package Persistencia;

import Dominio.Tarifa;
import Dominio.Habitacion;
import java.sql.Date;
import java.math.BigDecimal; // Asegúrate de tener esta línea
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PTarifa {
    private static Conexion conexion = new Conexion();

    // Agregar una nueva tarifa
    public static boolean agregarTarifa(Tarifa tarifa) {
        String sql = "INSERT INTO Tarifa(idHabitacion, fechaInicio, precioPorNoche) VALUES(?, ?, ?)";

        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                tarifa.getHabitacion().getIdHabitacion(),
                Date.valueOf(tarifa.getFechaInicio()),
                tarifa.getPrecioPorNoche()
        ));

        return conexion.consulta(sql, parametros);
    }

    // Eliminar una tarifa por su idTarifa
    public static boolean eliminarTarifa(int idTarifa) {
        String sql = "DELETE FROM Tarifa WHERE idTarifa=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(idTarifa));
        return conexion.consulta(sql, parametros);
    }

    // Modificar una tarifa existente
    public static boolean modificarTarifa(Tarifa tarifa) {
        String sql = "UPDATE Tarifa SET idHabitacion=?, fechaInicio=?, precioPorNoche=? WHERE idTarifa=?";

        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                tarifa.getHabitacion().getIdHabitacion(),
                Date.valueOf(tarifa.getFechaInicio()),
                tarifa.getPrecioPorNoche(),
                tarifa.getIdTarifa()
        ));

        return conexion.consulta(sql, parametros);
    }

    // Obtener una tarifa por su idTarifa
    public static Tarifa conseguirTarifa(int idTarifa) {
        String sql = "SELECT * FROM Tarifa WHERE idTarifa=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(idTarifa));

        List<List<Object>> resultado = conexion.seleccion(sql, parametros);
        if (resultado.isEmpty()) return null;

        List<Object> registro = resultado.get(0);
        Habitacion habitacion = PHabitacion.conseguirHabitacion((int) registro.get(1));

        return new Tarifa(
                (int) registro.get(0),
                habitacion,
                ((Date) registro.get(2)).toLocalDate(),
                ((BigDecimal) registro.get(3)).doubleValue() // Convertir BigDecimal a double
        );
    }

    // Listar todas las tarifas
    public static ArrayList<Tarifa> listarTarifas() {
        String sql = "SELECT * FROM Tarifa";
        List<List<Object>> registros = conexion.seleccion(sql, null);
        ArrayList<Tarifa> tarifas = new ArrayList<>();

        for (List<Object> registro : registros) {
            Habitacion habitacion = PHabitacion.conseguirHabitacion((int) registro.get(1)); // Obtener Habitacion
            Tarifa tarifa = new Tarifa(
                    (int) registro.get(0), // idTarifa
                    habitacion, // Pasar el objeto Habitacion
                    ((Date) registro.get(2)).toLocalDate(), // fechaInicio
                    ((BigDecimal) registro.get(3)).doubleValue() // Convertir BigDecimal a double
            );
            tarifas.add(tarifa);
        }
        return tarifas;
    }
}
