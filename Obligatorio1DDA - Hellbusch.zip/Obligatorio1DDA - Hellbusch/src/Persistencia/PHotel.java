package Persistencia;

import Dominio.Hotel;
import Dominio.Habitacion;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PHotel {
    private static Conexion conexion = new Conexion();

    // Agregar un nuevo hotel
    public static boolean agregarHotel(Hotel hotel) {
        String sql = "INSERT INTO hotel(idhotel, nombre, ciudad, pais, estrellas, direccion, zona) VALUES(?, ?, ?, ?, ?, ?, ?)";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                hotel.getIdHotel(), hotel.getNombre(), hotel.getCiudad(), hotel.getPais(),
                hotel.getEstrellas(), hotel.getDireccion(), hotel.getZona()
        ));
        return conexion.consulta(sql, parametros);
    }

    // Eliminar un hotel por su ID
    public static boolean eliminarHotel(int idHotel) {
        String sql = "DELETE FROM hotel WHERE idhotel=?";
        return conexion.consulta(sql, new ArrayList<>(Arrays.asList(idHotel)));
    }

    // Modificar los datos de un hotel
    public static boolean modificarHotel(Hotel hotel) {
        String sql = "UPDATE hotel SET nombre=?, ciudad=?, pais=?, estrellas=?, direccion=?, zona=? WHERE idhotel=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                hotel.getNombre(), hotel.getCiudad(), hotel.getPais(), hotel.getEstrellas(),
                hotel.getDireccion(), hotel.getZona(), hotel.getIdHotel()
        ));
        return conexion.consulta(sql, parametros);
    }

    // Conseguir un hotel específico por su ID
    public static Hotel conseguirHotel(int idHotel) {
        String sql = "SELECT * FROM hotel WHERE idhotel=?";
        List<List<Object>> resultado = conexion.seleccion(sql, new ArrayList<>(Arrays.asList(idHotel)));

        if (resultado.isEmpty()) return null;

        List<Object> registro = resultado.get(0);
        return new Hotel(
                (int) registro.get(0), String.valueOf(registro.get(1)), String.valueOf(registro.get(2)),
                String.valueOf(registro.get(3)), (int) registro.get(4), String.valueOf(registro.get(5)),
                String.valueOf(registro.get(6)), new ArrayList<Habitacion>() // Inicializa con una lista vacía
        );
    }

    // Listar todos los hoteles
    public static ArrayList<Hotel> listarHoteles() {
        String sql = "SELECT * FROM hotel";
        List<List<Object>> registros = conexion.seleccion(sql, null);
        ArrayList<Hotel> hoteles = new ArrayList<>();

        for (List<Object> registro : registros) {
            hoteles.add(new Hotel(
                    (int) registro.get(0), String.valueOf(registro.get(1)), String.valueOf(registro.get(2)),
                    String.valueOf(registro.get(3)), (int) registro.get(4), String.valueOf(registro.get(5)),
                    String.valueOf(registro.get(6)), new ArrayList<Habitacion>() // Inicializa con una lista vacía
            ));
        }
        return hoteles;
    }
}
