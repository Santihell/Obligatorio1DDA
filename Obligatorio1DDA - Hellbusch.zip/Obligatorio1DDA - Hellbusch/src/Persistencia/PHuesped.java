package Persistencia;

import Dominio.Huesped;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PHuesped {
    private static Conexion conexion = new Conexion();

    public static boolean agregarHuesped(Huesped huesped) {
        String sql = "INSERT INTO huesped(idHuesped, nombre, aPaterno, aMaterno, tipoDocumento, numDocumento, fechaNacimiento, telefono, pais) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                huesped.getIdHuesped(), huesped.getNombre(), huesped.getaPaterno(), huesped.getaMaterno(),
                huesped.getTipoDocumento(), huesped.getNumDocumento(), huesped.getFechaNacimiento(),
                huesped.getTelefono(), huesped.getPais()
        ));
        return conexion.consulta(sql, parametros);
    }

    public static boolean eliminarHuesped(int idHuesped) {
        String sql = "DELETE FROM huesped WHERE idHuesped=?";
        return conexion.consulta(sql, new ArrayList<>(Arrays.asList(idHuesped)));
    }

    public static boolean modificarHuesped(Huesped huesped) {
        String sql = "UPDATE huesped SET nombre=?, aPaterno=?, aMaterno=?, tipoDocumento=?, numDocumento=?, fechaNacimiento=?, telefono=?, pais=? WHERE idHuesped=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                huesped.getNombre(), huesped.getaPaterno(), huesped.getaMaterno(), huesped.getTipoDocumento(),
                huesped.getNumDocumento(), huesped.getFechaNacimiento(), // Se mantiene como String
                huesped.getTelefono(), huesped.getPais(), huesped.getIdHuesped()
        ));
        return conexion.consulta(sql, parametros);
    }

    public static Huesped conseguirHuesped(int idHuesped) {
        String sql = "SELECT * FROM huesped WHERE idHuesped=?";
        List<List<Object>> resultado = conexion.seleccion(sql, new ArrayList<>(Arrays.asList(idHuesped)));

        if (resultado.isEmpty()) return null; // Verificar si no hay resultados

        List<Object> registro = resultado.get(0);
        return new Huesped(
                (int) registro.get(0), String.valueOf(registro.get(1)), String.valueOf(registro.get(2)),
                String.valueOf(registro.get(3)), String.valueOf(registro.get(4)), String.valueOf(registro.get(5)),
                String.valueOf(registro.get(6)), String.valueOf(registro.get(7)), String.valueOf(registro.get(8))
        );
    }

    public static ArrayList<Huesped> listarHuespedes() {
        String sql = "SELECT * FROM huesped";
        List<List<Object>> registros = conexion.seleccion(sql, null);
        ArrayList<Huesped> huespedes = new ArrayList<>();

        for (List<Object> registro : registros) {
            huespedes.add(new Huesped(
                    (int) registro.get(0), String.valueOf(registro.get(1)), String.valueOf(registro.get(2)),
                    String.valueOf(registro.get(3)), String.valueOf(registro.get(4)), String.valueOf(registro.get(5)),
                    String.valueOf(registro.get(6)), String.valueOf(registro.get(7)), String.valueOf(registro.get(8))
            ));
        }
        return huespedes;
    }
}
